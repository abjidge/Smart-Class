package com.example.user1.fbdatastorage

class Hero (val id:String,  var subject:String)
{

    constructor() : this("","")
}